import React, { useEffect, useRef } from "react";
import Gal1 from "../assets/img/scroll1.jpg";
import Gal2 from "../assets/img/scroll2.mp4";
import Gal3 from "../assets/img/scroll3.jpg";
import Gal4 from "../assets/img/scroll4.jpg";
import Gal5 from "../assets/img/scroll5.jpg";
import Gal6 from "../assets/img/scroll6.mp4";
import Gal7 from "../assets/img/scroll7.jpg";
import Gal8 from "../assets/img/scroll8.jpg";
import arrowIcon from "../assets/img/arrow_icon.svg";
import ReactPlayer from "react-player";
import gsap, { Power1 } from "gsap";
import scrollTrigger from "gsap/ScrollTrigger";
import $ from "jquery";
gsap.registerPlugin(scrollTrigger);

const HorizontalGallery = () => {
	const galleryData = [
		{
			id: 1,
			img: Gal1,
			link: "/",
			name: "Nike X Lebron",
			type: "Type Design",
			color: "#000",
		},
		{
			id: 2,
			img: Gal2,
			link: "/",
			name: "Porsche",
			type: "Campaign",
			color: "#fff",
		},
		{
			id: 3,
			img: Gal3,
			link: "/",
			name: "Bang & Olufsen",
			type: "Design",
			color: "#fff",
		},
		{
			id: 4,
			img: Gal4,
			link: "/",
			name: "AM/PM",
			type: "Packaging",
			color: "#000",
		},
		{
			id: 5,
			img: Gal5,
			link: "/",
			name: "Aesop",
			type: "Campaign",
			color: "#000",
		},
		{
			id: 6,
			img: Gal6,
			link: "/",
			name: "Lululemon",
			type: "Editorial",
			color: "#fff",
		},
		{
			id: 7,
			img: Gal7,
			link: "/",
			name: "Anti",
			type: "Branding",
			color: "#fff",
		},
		{
			id: 8,
			img: Gal8,
			link: "/",
			name: "Teaquila",
			type: "Packaging",
			color: "#fff",
		},
	];
	useEffect(() => {
		// Second For pin
		const tlpin2 = gsap.timeline({
			scrollTrigger: {
				trigger: ".gallery",
				start: "top 0%",
				end: "top -100%",
				scrub: 1,
				pin: true,
				// markers: true,
			},
		});
		tlpin2.to(".gallery", {
			xPercent: -100,
			ease: Power1.easeInOut,
		});
	}, []);
	useEffect(() => {
		// gsap.set(".detailBtn", { x: 0, y: 0 });
		// let targetsBox = document.getElementById("#targetbox");
		$(".targetbox").on("mouseenter", function () {
			window.addEventListener("mousemove", (e) => {
				gsap.to(".detailBtn", {
					x: e.offsetX / 2,
					y: e.offsetY / 2,
					stagger: 0.035,
				});
			});
		});
		$(".targetbox").on("mouseleave", function () {
			window.removeEventListener("mousemove", (e) => {});
		});
	}, []);
	return (
		<>
			<section className="projects_sec py-5 overflow-hidden">
				<div className="title">
					<h2>PROJECTS</h2>
				</div>
				<div className="gallery">
					{galleryData?.map((items, index) => {
						return (
							<>
								{items?.img.split(".").pop() === "jpg" ? (
									<>
										<div
											className={`galleryBox scroll_${items?.id}`}
											key={index}
										>
											<div className="img_box position-relative targetbox">
												<img
													src={items?.img}
													alt="gal1"
													className="img-fluid"
												/>
												<div className="button-group detailBtn">
													<button className="link_btn">
														<span
															className="txt"
															style={{ color: items?.color }}
														>
															View
														</span>
														<span className="icon">
															<img
																src={arrowIcon}
																style={{
																	filter:
																		items?.color === "#fff"
																			? "brightness(0) invert(1)"
																			: "",
																}}
																alt="arrow_icon"
															/>
														</span>
													</button>
												</div>
											</div>
											<div className="detail_box d-flex align-items-center justify-content-between">
												<h5 className="name_of_scape">{items?.name}</h5>
												<h5 className="type">{items?.type}</h5>
											</div>
										</div>
									</>
								) : (
									<>
										<div className={`galleryBox scroll_${items?.id}`}>
											<div className="img_box position-relative targetbox">
												<ReactPlayer
													width="100%"
													height="250px"
													url={items?.img}
													loop={true}
													playing={true}
													muted={true}
												/>
												<div className="button-group detailBtn">
													<button className="link_btn">
														<span
															className="txt"
															style={{ color: items?.color }}
														>
															View
														</span>
														<span className="icon">
															<img
																src={arrowIcon}
																alt="arrow_icon"
																style={{
																	filter:
																		items?.color === "#fff"
																			? "brightness(0) invert(1)"
																			: "",
																}}
															/>
														</span>
													</button>
												</div>
											</div>
											<div className="detail_box d-flex align-items-center justify-content-between">
												<h5 className="name_of_scape">{items?.name}</h5>
												<h5 className="type">{items?.type}</h5>
											</div>
										</div>
									</>
								)}
							</>
						);
					})}
				</div>
			</section>
		</>
	);
};

export default HorizontalGallery;
